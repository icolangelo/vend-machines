SET lock_timeout = '5s';
START TRANSACTION;
ALTER TABLE "PaymentTransactions"
    ADD COLUMN IF NOT EXISTS "LastReconciliationAt" timestamp with time zone NULL;

COMMIT;

CREATE INDEX CONCURRENTLY IF NOT EXISTS "IX_PaymentTransactions_Status_LastReconciliationAt_CreatedAt"
ON "PaymentTransactions" ("Status", "LastReconciliationAt", "CreatedAt");

DO $$
DECLARE index_is_valid boolean;
BEGIN
    SELECT i.indisvalid AND i.indisready AND NOT i.indisunique
           AND i.indnkeyatts = 3
           AND pg_get_indexdef(i.indexrelid) LIKE '%("Status", "LastReconciliationAt", "CreatedAt")%'
      INTO index_is_valid
      FROM pg_index i
      JOIN pg_class index_relation ON index_relation.oid = i.indexrelid
      JOIN pg_namespace index_schema ON index_schema.oid = index_relation.relnamespace
     WHERE index_relation.relname = 'IX_PaymentTransactions_Status_LastReconciliationAt_CreatedAt'
       AND index_schema.nspname = current_schema();

    IF COALESCE(index_is_valid, FALSE) IS NOT TRUE THEN
        RAISE EXCEPTION 'O índice IX_PaymentTransactions_Status_LastReconciliationAt_CreatedAt está ausente ou inválido; remova-o com DROP INDEX CONCURRENTLY e repita a migration.';
    END IF;
END $$;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260926174359_AddPaymentReconciliationTracking', '10.0.12');

